package mk.ukim.finki.wp.lab.service.impl;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.repository.BookRepository;
import mk.ukim.finki.wp.lab.repository.AuthorRepository;
import mk.ukim.finki.wp.lab.service.BookService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public BookServiceImpl(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    @Override
    public List<Book> listAll() {
        return bookRepository.findAll();
    }

    @Override
    public List<Book> searchBooks(String text, Double rating) {
        // може да користиш custom query, за сега едноставно филтрирање:
        if ((text == null || text.isBlank()) && rating == null) {
            return bookRepository.findAll();
        }
        // едноставен пример: филтрирање in-memory или направи custom query во repo
        return bookRepository.findAll().stream()
                .filter(b -> text == null || b.getTitle().toLowerCase().contains(text.toLowerCase()))
                .filter(b -> rating == null || b.getAverageRating() >= rating)
                .toList();
    }

    @Override
    public Book findById(Long id) {
        return bookRepository.findById(id).orElse(null);
    }

    @Override
    public Book save(String title, String genre, double averageRating, Long authorId) {
        Optional<Author> authorOpt = authorRepository.findById(authorId);
        if (authorOpt.isEmpty()) return null;
        Book book = new Book(title, genre, averageRating, authorOpt.get());
        return bookRepository.save(book);
    }

    @Override
    public Book edit(Long id, String title, String genre, double averageRating, Long authorId) {
        Optional<Book> bookOpt = bookRepository.findById(id);
        Optional<Author> authorOpt = authorRepository.findById(authorId);
        if (bookOpt.isEmpty() || authorOpt.isEmpty()) return null;

        Book book = bookOpt.get();
        book.setTitle(title);
        book.setGenre(genre);
        book.setAverageRating(averageRating);
        book.setAuthor(authorOpt.get());
        return bookRepository.save(book);
    }

    @Override
    public void delete(Long id) {
        bookRepository.deleteById(id);
    }

    @Override
    public List<Book> findAllByAuthorId(Long authorId) {
        return bookRepository.findAllByAuthor_Id(authorId);
    }
}
