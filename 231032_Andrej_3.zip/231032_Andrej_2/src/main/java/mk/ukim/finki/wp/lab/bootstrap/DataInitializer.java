package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.repository.AuthorRepository;
import mk.ukim.finki.wp.lab.repository.BookRepository;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("h2")
public class DataInitializer {

    private final AuthorRepository authorRepository;
    private final BookRepository bookRepository;

    public DataInitializer(AuthorRepository authorRepository, BookRepository bookRepository) {
        this.authorRepository = authorRepository;
        this.bookRepository = bookRepository;
    }

    @PostConstruct
    public void init() {
        Author a1 = authorRepository.save(new Author("Jane", "Austen", "UK", "Jane Austen..."));
        Author a2 = authorRepository.save(new Author("J.R.R.", "Tolkien", "UK", "Tolkien..."));
        Author a3 = authorRepository.save(new Author("Dan", "Brown", "USA", "Dan Brown..."));

        bookRepository.save(new Book("Pride and Prejudice", "Romance", 4.6, a1));
        bookRepository.save(new Book("The Hobbit", "Fantasy", 4.8, a2));
        bookRepository.save(new Book("The Da Vinci Code", "Thriller", 4.3, a3));

    }
}
