package mk.ukim.finki.wp.lab.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.service.BookService;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@ServletComponentScan
@SpringBootApplication
@WebServlet(name = "bookListServlet", urlPatterns = "")
public class BookListServlet extends HttpServlet {

    private final BookService bookService;

    public BookListServlet(BookService bookService) {
        this.bookService = bookService;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String text = req.getParameter("text");
        String ratingStr = req.getParameter("rating");

        List<Book> books;

        if (text != null && ratingStr != null && !text.isEmpty() && !ratingStr.isEmpty()) {
            Double rating = Double.parseDouble(ratingStr);
            books = bookService.searchBooks(text, rating);
        } else {
            books = bookService.listAll();
        }

        resp.setContentType("text/html; charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("""
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="utf-8">
                    <title>Book Reservation - Welcome and choose a Book</title>
                    <style type="text/css">
                        body { width: 800px; margin: auto; font-family: Arial, sans-serif; }
                        h1 { color: #333; }
                        form { margin-top: 20px; }
                        .book-option { margin: 10px 0; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
                        .book-option:hover { background-color: #f5f5f5; }
                    </style>
                </head>
                <body>
                    <header><h1>Welcome to our Book Reservation App</h1></header>
                    <main>
                        <form method='get' action='/'>
                            <label>Search by title:</label>
                            <input type='text' name='text' placeholder='Enter text'>
                            <label>Min rating:</label>
                            <input type='number' name='rating' step='0.1' min='0' max='5'>
                            <input type='submit' value='Search'>
                        </form>
                        
                        <form action='/bookReservation' method='POST'>
                            <h2>Choose a book:</h2>
                """);

        for (Book b : books) {
            out.printf("<div class='book-option'><label><input type='radio' name='book' value='%s' required> Title: %s, Genre: %s, Rating: %.1f</label></div>%n",
                    b.getTitle(), b.getTitle(), b.getGenre(), b.getAverageRating());
        }

        out.println("""
                            <h2>Enter your information:</h2>
                            <label>Your Name:</label>
                            <input type="text" name="readerName" required><br/>
                            <label>Your Address:</label>
                            <input type="text" name="readerAddress" required><br/>

                            <h2>Choose number of copies:</h2>
                            <input type="number" name="numCopies" min="1" max="10" required><br/><br/>
                            <input type="submit" value="Reserve Book">
                        </form>
                    </main>
                </body>
                </html>
                """);
    }
}
