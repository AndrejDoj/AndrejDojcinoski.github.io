package mk.ukim.finki.wp.lab.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import mk.ukim.finki.wp.lab.model.BookReservation;
import mk.ukim.finki.wp.lab.service.BookReservationService;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@ServletComponentScan
@WebServlet(name = "bookReservationServlet", urlPatterns = "/bookReservation")
public class BookReservationServlet extends HttpServlet {

    private final BookReservationService reservationService;

    public BookReservationServlet(BookReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String bookTitle = req.getParameter("book");
        String readerName = req.getParameter("readerName");
        String readerAddress = req.getParameter("readerAddress");
        int numCopies = Integer.parseInt(req.getParameter("numCopies"));

        // IP адреса на клиентот
        String clientIp = req.getRemoteAddr();

        // Креирај резервација
        BookReservation reservation = reservationService.placeReservation(
                bookTitle, readerName, readerAddress, numCopies
        );

        // Постави атрибути за прикажување на потврдата
        req.setAttribute("reservation", reservation);
        req.setAttribute("ipAddress", clientIp);

        req.getRequestDispatcher("/templates/reservationConfirmation.html").forward(req, resp);
    }
}
