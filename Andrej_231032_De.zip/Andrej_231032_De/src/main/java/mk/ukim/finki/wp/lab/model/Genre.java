package mk.ukim.finki.wp.lab.model;

public enum Genre {
    FANTASY("Fantasy"),
    SCIENCE_FICTION("Science Fiction"),
    DYSTOPIAN("Dystopian"),
    GOTHIC_NOVEL("Gothic Novel"),
    NOVEL("Novel"),
    SCI_FI("Sci-Fi"),
    ROMANCE("Romance"),
    MYSTERY("Mystery"),
    BIOGRAPHY("Biography"),
    HISTORICAL_FICTION("Historical Fiction"),
    ADVENTURE("Adventure");

    private final String displayName;

    Genre(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    // Дополнително: статички метод за да најдеш Genre по displayName
    public static Genre fromDisplayName(String displayName) {
        for (Genre genre : values()) {
            if (genre.getDisplayName().equalsIgnoreCase(displayName)) {
                return genre;
            }
        }
        throw new IllegalArgumentException("Unknown genre: " + displayName);
    }
}