package mk.ukim.finki.wp.lab.web.controller;

import jakarta.servlet.http.HttpSession;
import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.Genre;
import mk.ukim.finki.wp.lab.service.AuthorService;
import mk.ukim.finki.wp.lab.service.BookService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/books")
public class BookController {
    private final BookService bookService;
    private final AuthorService authorService;

    public BookController(BookService bookService, AuthorService authorService) {
        this.bookService = bookService;
        this.authorService = authorService;
    }

    @GetMapping
    @SuppressWarnings("unchecked")
    public String getBooksPage(@RequestParam(required = false) String error,
                               @RequestParam(required = false) String filterAuthorId,
                               @RequestParam(required = false) String filterGenre,
                               Model model,
                               HttpSession session) {
        if (error != null) {
            model.addAttribute("error", error);
        }

        List<Book> books;
        List<String> lastViewed = (List<String>) session.getAttribute("lastViewed");

        long authorId = -1L;
        Genre selectedGenre = null;

        try {
            if (filterAuthorId != null && !filterAuthorId.equals("-1")) {
                authorId = Long.parseLong(filterAuthorId);
            }
        } catch (Exception e) {
            // ignore
        }

        try {
            if (filterGenre != null && !filterGenre.equals("-1") && !filterGenre.isEmpty()) {
                selectedGenre = Genre.valueOf(filterGenre);
            }
        } catch (Exception e) {
            System.out.println("Invalid genre: " + filterGenre);
        }

        if (authorId != -1 && selectedGenre != null) {
            books = bookService.findBooksByAuthorIdAndGenre(authorId, selectedGenre);
        } else if (authorId != -1) {
            books = bookService.findBooksByAuthorId(authorId);
        } else if (selectedGenre != null) {
            books = bookService.findBooksByGenre(selectedGenre);
        } else {
            books = bookService.listAll();
        }

        model.addAttribute("books", books);
        model.addAttribute("lastViewedBooks", lastViewed);
        model.addAttribute("authors", authorService.findAll());
        model.addAttribute("allGenres", Arrays.asList(Genre.values()));  // Сите enum вредности
        model.addAttribute("filteredId", authorId);
        model.addAttribute("filteredGenre", selectedGenre != null ? selectedGenre.name() : "-1");
        return "listBooks";
    }

    @GetMapping("/book-form")
    public String getAddBookPage(Model model) {
        model.addAttribute("authors", authorService.findAll());
        model.addAttribute("allGenres", Arrays.asList(Genre.values()));  // Додадено
        return "book-form";
    }

    @PostMapping("/add")
    public String saveBook(@RequestParam String title,
                           @RequestParam String genre,  // Променето: String наместо Long
                           @RequestParam Double averageRating,
                           @RequestParam Long authorId) {
        Genre genreEnum;
        try {
            genreEnum = Genre.valueOf(genre);
        } catch (IllegalArgumentException e) {
            return "redirect:/books?error=Invalid genre selected";
        }
        bookService.add(title, genreEnum, averageRating, authorId);
        return "redirect:/books";
    }

    @GetMapping("/book-form/{bookId}")
    public String getEditBookForm(@PathVariable Long bookId, Model model) {
        if (bookId == null) {
            return "redirect:/books?error=BookNotFound";
        }

        Book book = bookService.findBook(bookId);
        if (book == null) {
            return "redirect:/books?error=BookNotFound";
        }

        model.addAttribute("bookId", book.getId());
        model.addAttribute("title", book.getTitle());
        model.addAttribute("averageRating", book.getAverageRating());

        Author author = book.getAuthor();
        model.addAttribute("authorId", author != null ? author.getId() : -1);

        Genre genre = book.getGenre();
        model.addAttribute("genre", genre != null ? genre.name() : "-1");  // Променето

        model.addAttribute("authors", authorService.findAll());
        model.addAttribute("allGenres", Arrays.asList(Genre.values()));  // Додадено
        return "book-form";
    }

    @PostMapping("/edit/{bookId}")
    public String editBook(@PathVariable Long bookId,
                           @RequestParam String title,
                           @RequestParam String genre,  // Променето: String наместо Long
                           @RequestParam Double averageRating,
                           @RequestParam Long authorId) {
        Genre genreEnum;
        try {
            genreEnum = Genre.valueOf(genre);
        } catch (IllegalArgumentException e) {
            return "redirect:/books?error=Invalid genre selected";
        }
        bookService.update(bookId, title, genreEnum, averageRating, authorId);
        return "redirect:/books";
    }

    @PostMapping("/delete/{bookId}")
    public String deleteBook(@PathVariable Long bookId) {
        bookService.delete(bookId);
        return "redirect:/books";
    }
}