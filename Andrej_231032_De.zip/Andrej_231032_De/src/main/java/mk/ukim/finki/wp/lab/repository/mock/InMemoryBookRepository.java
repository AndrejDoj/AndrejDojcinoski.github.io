package mk.ukim.finki.wp.lab.repository.mock;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.Genre;  // Genre е сега Enum

import java.util.List;

public interface InMemoryBookRepository {
    List<Book> findAll();
    List<Book> searchBooks(String text, double rating);
    List<Book> findAllByAuthor_Id(Long authorId);
    List<Book> findAllByGenre(Genre genre);  // Променето: Genre наместо Long

    Book findBook(Long id);
    Book add(String title, Genre genre, Double averageRating, Author author);  // Променето
    Book update(Long id, String title, Genre genre, Double averageRating, Author author);  // Променето
    void delete(Long id);
}