package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.Genre;

import java.util.List;

public interface BookService {
    List<Book> listAll();
    List<Book> searchBooks(String text, double rating);

    Book findBook(Long id);
    List<Book> findBooksByAuthorId(Long authorId);
    List<Book> findBooksByGenre(Genre genre);  // Променето: Genre наместо Long
    List<Book> findBooksByAuthorIdAndGenre(Long authorId, Genre genre);  // Променето
    Book add(String title, Genre genre, Double averageRating, Long authorId);  // Променето
    Book update(Long id, String title, Genre genre, Double averageRating, Long authorId);  // Променето
    void delete(Long id);
}