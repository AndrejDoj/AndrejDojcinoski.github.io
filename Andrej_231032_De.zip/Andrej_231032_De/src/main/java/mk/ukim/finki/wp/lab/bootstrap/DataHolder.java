package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.BookReservation;
import mk.ukim.finki.wp.lab.model.Genre;
import mk.ukim.finki.wp.lab.repository.jpa.AuthorRepository;
import mk.ukim.finki.wp.lab.repository.jpa.BookRepository;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Book> books = new ArrayList<>();
    public static List<BookReservation> reservations = new ArrayList<>();

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public DataHolder(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    @PostConstruct
    public void init() {
        // 1. Креирај автори
        if (authorRepository.count() == 0) {
            List<Author> authors = List.of(
                    new Author("J.K", "Rowling", "England", "J.K Rowling biography"),
                    new Author("J.R.R", "Tolkien", "England", "J.R.R Tolkien biography"),
                    new Author("George", "Orwell", "England", "George Orwell biography"),
                    new Author("Andy", "Weir", "United States", "Andy Weir biography"),
                    new Author("Douglas", "Adams", "England", "Douglas Adams biography"),
                    new Author("Aldous", "Huxley", "England", "Aldous Huxley biography"),
                    new Author("Mary", "Shelley", "England", "Mary Shelley biography"),
                    new Author("Frank", "Herbert", "United States", "Frank Herbert biography"),
                    new Author("Suzanne", "Collins", "United States", "Suzanne Collins biography"),
                    new Author("Arthur C.", "Clarke", "England", "Arthur C. Clarke biography")
            );
            authorRepository.saveAll(authors);
        }

        // 2. Креирај книги со ENUM жанрови
        if (bookRepository.count() == 0) {
            List<Author> authors = authorRepository.findAll();

            books = List.of(
                    new Book("Harry Potter", Genre.FANTASY, 5.0),
                    new Book("Lord of the Rings", Genre.FANTASY, 3.2),
                    new Book("1984", Genre.DYSTOPIAN, 4.5),
                    new Book("Project Hail Mary", Genre.SCIENCE_FICTION, 4.8),
                    new Book("The Hitchhiker's Guide To The Galaxy", Genre.SCI_FI, 4.2),
                    new Book("Brave New World", Genre.DYSTOPIAN, 3.7),
                    new Book("Frankenstein", Genre.GOTHIC_NOVEL, 4.6),
                    new Book("Dune", Genre.SCIENCE_FICTION, 4.3),
                    new Book("The Hunger Games", Genre.DYSTOPIAN, 4.9),
                    new Book("2001: A Space Odyssey", Genre.SCIENCE_FICTION, 4.5)
            );

            // Додели автори на книги
            for (int i = 0; i < books.size(); i++) {
                Book book = books.get(i);
                if (i < authors.size()) {
                    book.setAuthor(authors.get(i));
                } else {
                    book.setAuthor(authors.get(i % authors.size()));
                }
            }

            bookRepository.saveAll(books);
        }
    }
}